# Best Vet Clinic and Pet Shop — Full Website + Backend

## Included
- `public/index.html`: customer-facing website and appointment form
- `server.js`: Express backend and appointment API
- `public/admin.html`: password-protected clinic dashboard
- SQLite database for appointment records and admin sessions

## Run locally
Requires Node.js 20 or newer.

1. Install dependencies:
   `npm install`
2. Create `.env` from `.env.example`.
3. Generate a password hash for the clinic admin:
   `node -e "require('bcryptjs').hash('CHOOSE_A_STRONG_PASSWORD', 12).then(console.log)"`
4. Paste the printed hash into `ADMIN_PASSWORD_HASH` in `.env`.
5. Replace `SESSION_SECRET` with a long random secret.
6. Start:
   `npm start`
7. Open `http://localhost:3000` for the website.
8. Open `http://localhost:3000/admin` for the clinic dashboard.

## Appointment flow
Customers submit the form on the website. The server validates and stores requests in `data/appointments.sqlite`. The clinic signs in at `/admin` to view requests, call customers, and update statuses.

## Deployment notes
Deploy as a Node.js web service. Set `NODE_ENV=production`, `SESSION_SECRET`, and `ADMIN_PASSWORD_HASH` as environment variables. Attach persistent disk storage and set `DATA_DIR` to that disk's mount path, otherwise SQLite data may be lost on redeploy/restart. Use HTTPS. Do not commit `.env` or share the admin password. Configure backups and restrict dashboard access to authorized clinic staff.

This starter stores customer contact details. The clinic should publish a privacy notice, collect only information it needs, limit staff access, and set a retention/deletion policy. The form sends requests, not confirmed bookings; staff must confirm availability with the customer.

## Important
The backend package is prepared but has not been deployed or connected to a live domain. A live deployment requires hosting account setup and environment variables controlled by the clinic owner.
