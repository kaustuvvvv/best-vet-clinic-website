require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "appointments.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS appointments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 owner_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 pet_type TEXT NOT NULL,
 service TEXT NOT NULL,
 preferred_date TEXT NOT NULL,
 preferred_time TEXT,
 message TEXT,
 status TEXT NOT NULL DEFAULT 'New',
 created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

if (!process.env.SESSION_SECRET || !process.env.ADMIN_PASSWORD_HASH) {
  console.error("Missing SESSION_SECRET or ADMIN_PASSWORD_HASH. Copy .env.example to .env and configure it.");
  process.exit(1);
}
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: DATA_DIR }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));

const submitLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false });

function clean(value, max) {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}
function validDate(value) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value));
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.admin === true) return next();
  return res.status(401).json({ error: "Please log in to the admin dashboard." });
}

app.post("/api/appointments", submitLimiter, (req, res) => {
  const owner_name = clean(req.body.owner_name, 100);
  const phone = clean(req.body.phone, 30);
  const pet_type = clean(req.body.pet_type, 30);
  const service = clean(req.body.service, 80);
  const preferred_date = clean(req.body.preferred_date, 10);
  const preferred_time = clean(req.body.preferred_time, 5);
  const message = clean(req.body.message, 1000);

  if (!owner_name || !phone || !pet_type || !service || !validDate(preferred_date)) {
    return res.status(400).json({ error: "Please complete the required fields with a valid appointment date." });
  }
  if (!/^[0-9+()\-.\s]{7,30}$/.test(phone)) {
    return res.status(400).json({ error: "Please enter a valid phone number." });
  }
  const result = db.prepare(`
    INSERT INTO appointments (owner_name, phone, pet_type, service, preferred_date, preferred_time, message)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(owner_name, phone, pet_type, service, preferred_date, preferred_time, message);
  res.status(201).json({ ok: true, id: result.lastInsertRowid });
});

app.post("/api/admin/login", loginLimiter, async (req, res) => {
  const password = clean(req.body.password, 200);
  const valid = await bcrypt.compare(password, process.env.ADMIN_PASSWORD_HASH);
  if (!valid) return res.status(401).json({ error: "Incorrect password." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start admin session." });
    req.session.admin = true;
    res.json({ ok: true });
  });
});
app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/admin/me", (req, res) => res.json({ authenticated: !!(req.session && req.session.admin) }));
app.get("/api/admin/appointments", requireAdmin, (req, res) => {
  const rows = db.prepare("SELECT * FROM appointments ORDER BY created_at DESC, id DESC").all();
  res.json(rows);
});
app.patch("/api/admin/appointments/:id", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const status = clean(req.body.status, 20);
  if (!Number.isInteger(id) || !["New", "Contacted", "Confirmed", "Completed", "Cancelled"].includes(status)) {
    return res.status(400).json({ error: "Invalid appointment or status." });
  }
  const result = db.prepare("UPDATE appointments SET status = ? WHERE id = ?").run(status, id);
  if (!result.changes) return res.status(404).json({ error: "Appointment not found." });
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public")));
app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Best Vet Clinic website running on port ${PORT}`));
